package br.com.atous.demo.entrypoints.rest.dto;

public record SearchResponse(String message, Object result) {
} 